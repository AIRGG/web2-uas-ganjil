<div class="container-fluid">
<h1>Dashboard Admin</h1>
</div>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
      <li class="nav-item">
          <a class="nav-link" href="index.php">Utama</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="setup-dosen.php">Setup Dosen</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="setup-ruang.php">Setup Ruang</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="setup-kelas.php">Setup Kelas</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="matkul.php">Setup Matkul</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="upload-excel.php">Upload Excel</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="?act=logout">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

